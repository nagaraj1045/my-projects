  
  <!doctype html>
<html lang="en">
 <head>
  <title>Document</title>
 </head>
 <body>
 <form action="ramini.php" method="post">
 <table>
 <tr>
 <td><input type="submit" name="inc" value="+" /></td>
 </tr>
 </table>
 </form>
 </body>
</html>

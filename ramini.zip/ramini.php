<!doctype html>
<html lang="en">
 <head>
  <title>Document</title>
 <?php 
 session_start();
 ?>
 </head>
 <body>
  <?php
  if(isset($_POST["car_slots"]))
  {
$_SESSION["text"]=$_POST["text"];
  }
 if(isset($_POST["inc"]))
 {
  if($_SESSION["inc"]<=$_SESSION["text"])
	 {
 $_SESSION["inc"];
 $_SESSION["inc"]=$_SESSION["inc"]+1;
 echo "<h1>The no of cars entered is ".$_SESSION["inc"]."</h1>";
 $s=$_SESSION["text"]-$_SESSION["inc"];
 echo "<p><h1> The no of slots available after booking is ".$s."</h1></p>";
	 }
	 else
	 {
		 echo "bookings are full<br/>";
	 }
 }
 else if(isset($_POST["dec"]))
 {
	
	if($_SESSION["inc"]!=0)
	 {
	 $_SESSION["inc"]=$_SESSION["inc"]-1;
  echo "<h1>The no of cars which exit the slots were ".$_SESSION["inc"]."</h1>";
	 $d=$_SESSION["text"]-$_SESSION["inc"];
	 echo "<p><h1>the no of slots reamined after cars took exit were ".$d."</h1></p><br/>";
	 }
	 else
	 {
		 echo "all slots are empty";
	 }
 }
  ?>
 </body>
</html>
